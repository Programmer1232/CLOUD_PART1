using BhoroDJLM.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton(sp => new ProductService("DefaultEndpointsProtocol=https;AccountName=st10083732;AccountKey=IMGQxrzYUx1MweZks63y6K2o7sjUwwgDl3WUyzn9bpjjA2v0fZGxwNTBmL4YYAdRSgwBRQViPfO8+AStqhGpww==;EndpointSuffix=core.windows.net"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
