﻿using Azure;
using Azure.Data.Tables;

namespace BhoroDJLM.Models
{
    public class Product : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }

        // Ensure a parameterless constructor
        public Product()
        {
        }

        // Parameterized constructor to create an instance easily
        public Product(string partitionKey, string rowKey, string name, decimal price, string description, string imageUrl)
        {
            PartitionKey = partitionKey;
            RowKey = rowKey;
            Name = name;
            Price = price;
            Description = description;
            ImageUrl = imageUrl;
        }
    }
}
