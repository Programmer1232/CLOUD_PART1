﻿using Azure.Data.Tables;
using BhoroDJLM.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BhoroDJLM.Services
{
    public class ProductService
    {
        private readonly TableClient _tableClient;

        public ProductService(string connectionString)
        {
            var serviceClient = new TableServiceClient(connectionString);
            _tableClient = serviceClient.GetTableClient("Products");
            _tableClient.CreateIfNotExists(); // Ensure table exists
        }

        public async Task<IEnumerable<Product>> GetProductsAsync()
        {
            var products = new List<Product>();

            await foreach (var entity in _tableClient.QueryAsync<Product>())
            {
                products.Add(entity);
            }

            return products;
        }

        public async Task AddProductAsync(Product product)
        {
            await _tableClient.UpsertEntityAsync(product);
        }
    }
}
