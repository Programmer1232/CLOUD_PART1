﻿using Azure.Data.Tables;

public class TableService
{
    private readonly TableClient _tableClient;

    public TableService(IConfiguration configuration)
    {
        var tableServiceClient = new TableServiceClient(configuration["DefaultEndpointsProtocol=https;AccountName=st10083732;AccountKey=IMGQxrzYUx1MweZks63y6K2o7sjUwwgDl3WUyzn9bpjjA2v0fZGxwNTBmL4YYAdRSgwBRQViPfO8+AStqhGpww==;EndpointSuffix=core.windows.net"]);
        _tableClient = tableServiceClient.GetTableClient("CustomerFiles");
    }

    public async Task AddOrUpdateEntityAsync(TableEntity entity)
    {
        await _tableClient.UpsertEntityAsync(entity);
    }
}
