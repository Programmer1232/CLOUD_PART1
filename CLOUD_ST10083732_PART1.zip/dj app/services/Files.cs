﻿using Azure.Storage.Files.Shares;

public class FileService
{
    private readonly ShareClient _shareClient;

    public FileService(IConfiguration configuration)
    {
        var fileServiceClient = new ShareServiceClient(configuration["DefaultEndpointsProtocol=https;AccountName=st10083732;AccountKey=IMGQxrzYUx1MweZks63y6K2o7sjUwwgDl3WUyzn9bpjjA2v0fZGxwNTBmL4YYAdRSgwBRQViPfO8+AStqhGpww==;EndpointSuffix=core.windows.net"]);
        _shareClient = fileServiceClient.GetShareClient("contracts");
    }

    public async Task UploadFileAsync(string fileName, Stream fileStream)
    {
        var fileClient = _shareClient.GetDirectoryClient("files").GetFileClient(fileName);
        await fileClient.CreateAsync(fileStream.Length);
        await fileClient.UploadAsync(fileStream);
    }
}
