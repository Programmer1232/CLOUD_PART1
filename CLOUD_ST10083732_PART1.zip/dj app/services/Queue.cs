﻿using Azure.Storage.Queues;

public class QueueService
{
    private readonly QueueClient _queueClient;

    public QueueService(IConfiguration configuration)
    {
        var queueServiceClient = new QueueServiceClient(configuration["DefaultEndpointsProtocol=https;AccountName=st10083732;AccountKey=IMGQxrzYUx1MweZks63y6K2o7sjUwwgDl3WUyzn9bpjjA2v0fZGxwNTBmL4YYAdRSgwBRQViPfO8+AStqhGpww==;EndpointSuffix=core.windows.net"]);
        _queueClient = queueServiceClient.GetQueueClient("orders");
    }

    public async Task SendMessageAsync(string message)
    {
        await _queueClient.SendMessageAsync(message);
    }

    public async Task<string> ReceiveMessageAsync()
    {
        var response = await _queueClient.ReceiveMessageAsync();
        return response.Value.MessageText;
    }
}
