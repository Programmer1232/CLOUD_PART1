﻿using Azure.Storage.Blobs;

public class BlobService
{
    private readonly BlobServiceClient _blobServiceClient;

    public BlobService(IConfiguration configuration)
    {
        _blobServiceClient = new BlobServiceClient(configuration["DefaultEndpointsProtocol=https;AccountName=st10083732;AccountKey=IMGQxrzYUx1MweZks63y6K2o7sjUwwgDl3WUyzn9bpjjA2v0fZGxwNTBmL4YYAdRSgwBRQViPfO8+AStqhGpww==;EndpointSuffix=core.windows.net"]);
    }

    public async Task UploadFileAsync(string containerName, string fileName, Stream fileStream)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
        await containerClient.CreateIfNotExistsAsync();
        var blobClient = containerClient.GetBlobClient(fileName);
        await blobClient.UploadAsync(fileStream, overwrite: true);
    }

    public async Task<Stream> DownloadFileAsync(string containerName, string fileName)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
        var blobClient = containerClient.GetBlobClient(fileName);
        var downloadInfo = await blobClient.DownloadAsync();
        return downloadInfo.Value.Content;
    }
}
