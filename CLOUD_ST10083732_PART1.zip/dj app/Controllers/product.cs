﻿using BhoroDJLM.Models;
using BhoroDJLM.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BhoroDJLM.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductService _productService;

        public ProductController(ProductService productService)
        {
            _productService = productService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetProductsAsync();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            if (ModelState.IsValid)
            {
                await _productService.AddProductAsync(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // Implement other actions: Edit, Delete, Details
    }
}
